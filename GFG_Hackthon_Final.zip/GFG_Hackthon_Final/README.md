# olympics-data-analysis-web-app
A Streamlit web application for the analysis of olympics dataset

Dataset Link: https://www.kaggle.com/heesoo37/120-years-of-olympic-history-athletes-and-results

Live Demo: https://oda-campusx.herokuapp.com/
